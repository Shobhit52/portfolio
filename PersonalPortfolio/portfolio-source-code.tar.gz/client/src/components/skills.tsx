import { motion } from "framer-motion";
import { Laptop, Server, Wrench } from "lucide-react";

export default function Skills() {
  const skillCategories = [
    {
      title: "Frontend",
      icon: Laptop,
      color: "blue",
      skills: [
        { name: "React.js", level: 4 },
        { name: "TypeScript", level: 5 },
        { name: "Tailwind CSS", level: 4 },
        { name: "Next.js", level: 4 },
      ],
    },
    {
      title: "Backend",
      icon: Server,
      color: "green",
      skills: [
        { name: "Node.js", level: 5 },
        { name: "Python", level: 4 },
        { name: "PostgreSQL", level: 4 },
        { name: "AWS", level: 3 },
      ],
    },
    {
      title: "Tools & Others",
      icon: Wrench,
      color: "purple",
      skills: [
        { name: "Git", level: 5 },
        { name: "Docker", level: 4 },
        { name: "Figma", level: 4 },
        { name: "Agile/Scrum", level: 4 },
      ],
    },
  ];

  const SkillDots = ({ level }: { level: number }) => (
    <div className="flex space-x-1">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className={`w-2 h-2 rounded-full ${
            i < level ? "bg-current" : "bg-slate-300"
          }`}
        />
      ))}
    </div>
  );

  return (
    <section id="skills" className="py-20 bg-slate-50">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Skills & Technologies
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            A comprehensive toolkit for building modern, scalable applications.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.2 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div
                className={`w-16 h-16 ${
                  category.color === "blue"
                    ? "bg-blue-100 text-primary"
                    : category.color === "green"
                    ? "bg-green-100 text-accent"
                    : "bg-purple-100 text-purple-600"
                } rounded-lg flex items-center justify-center mb-6`}
              >
                <category.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-4">
                {category.title}
              </h3>
              <div className="space-y-3">
                {category.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className="flex items-center justify-between"
                  >
                    <span className="text-slate-600">{skill.name}</span>
                    <div
                      className={
                        category.color === "blue"
                          ? "text-primary"
                          : category.color === "green"
                          ? "text-accent"
                          : "text-purple-600"
                      }
                    >
                      <SkillDots level={skill.level} />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8 mt-16"
        >
          <img
            src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
            alt="Close-up view of coding environment with code editor and multiple monitors"
            className="rounded-xl shadow-lg w-full h-64 object-cover"
          />
          <img
            src="https://images.unsplash.com/photo-1484417894907-623942c8ee29?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400"
            alt="Modern tech workspace with laptop, notebook, and development tools"
            className="rounded-xl shadow-lg w-full h-64 object-cover"
          />
        </motion.div>
      </div>
    </section>
  );
}
