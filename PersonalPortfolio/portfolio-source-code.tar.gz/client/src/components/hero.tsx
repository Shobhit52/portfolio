import { Button } from "@/components/ui/button";
import { Github, Linkedin, Twitter, Mail, Code } from "lucide-react";
import { motion } from "framer-motion";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 pt-20"
    >
      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight">
                Hi, I'm <span className="text-primary">Ben</span>
              </h1>
              <h2 className="text-2xl md:text-3xl text-slate-600 font-light">
                Full Stack Developer
              </h2>
              <p className="text-lg text-slate-600 leading-relaxed max-w-lg">
                I create exceptional digital experiences through clean code and
                innovative solutions. Passionate about building scalable
                applications that make a difference.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button
                onClick={() => scrollToSection("projects")}
                className="bg-primary text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                View My Work
              </Button>
              <Button
                variant="outline"
                onClick={() => scrollToSection("contact")}
                className="border-2 border-primary text-primary px-8 py-3 rounded-lg font-medium hover:bg-primary hover:text-white transition-all duration-200"
              >
                Get In Touch
              </Button>
            </div>

            <div className="flex space-x-6 pt-4">
              <a
                href="https://github.com"
                className="text-slate-400 hover:text-primary transition-colors duration-200 text-xl"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github className="w-6 h-6" />
              </a>
              <a
                href="https://linkedin.com"
                className="text-slate-400 hover:text-primary transition-colors duration-200 text-xl"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Linkedin className="w-6 h-6" />
              </a>
              <a
                href="https://twitter.com"
                className="text-slate-400 hover:text-primary transition-colors duration-200 text-xl"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Twitter className="w-6 h-6" />
              </a>
              <a
                href="mailto:ben@benrogers.dev"
                className="text-slate-400 hover:text-primary transition-colors duration-200 text-xl"
              >
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
                alt="Professional headshot of Ben Rogers"
                className="w-80 h-80 object-cover rounded-2xl shadow-2xl mx-auto"
              />
              <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-accent rounded-full flex items-center justify-center shadow-xl">
                <Code className="text-white text-2xl w-8 h-8" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
